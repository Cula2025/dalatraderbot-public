# -*- coding: utf-8 -*-
import datetime as _dt
try:
    import streamlit as st
except Exception:
    st = None

DEBUG_KEY = "debug_enabled"

def setup_debug_ui(page_title: str = "") -> bool:
    """Visar en Debug-checkbox (default: av). Returnerar True/False."""
    if st is None:
        return False
    st.sidebar.subheader("🛠️ Debug")
    enabled = st.sidebar.checkbox("Debug", value=False, key=DEBUG_KEY)
    return enabled

def log(msg: str, level: str = "INFO", ui: bool = False) -> None:
    """Logga alltid till stdout (journald), visa i UI bara om ui=True och checkbox är på."""
    ts = _dt.datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {level}: {msg}"
    try:
        print(line, flush=True)  # journald via systemd
    except Exception:
        pass
    if ui and st is not None and st.session_state.get(DEBUG_KEY):
        try:
            st.sidebar.caption(line)
        except Exception:
            pass
